function App() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-[#558B6E]">
      <h1 className="text-5xl font-bold text-[#F2D64F]">
        TRACE
      </h1>
    </div>
  )
}

export default App